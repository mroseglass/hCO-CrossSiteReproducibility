library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

#INPUTS ########################################################################################
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/iDISCO/"
rds.here <- "/work/users/r/o/roseg/IDDRC/IDDRC_EVOS/"
b.t.v <- read_csv(paste0(db.here, "IDDRC_D84_Best_ToPRO.csv"))
s.t.v <- read_csv(paste0(db.here, "IDDRC_D84_Smol_TotalVolume.csv"))
b.ctip2.spot <- read_csv(paste0(db.here, "IDDRC_D84_Best_CTIP2Spots.csv"))
s.ctip2.spot <- read_csv(paste0(db.here, "IDDRC_D84_Smol_CTIP2Spots.csv"))
b.cinvz <- read_csv(paste0(db.here, "IDDRC_D84_Best_CTIP2inVZ.csv"))
s.cinvz <- read_csv(paste0(db.here, "IDDRC_D84_Smol_CTIP2inVZ.csv"))
b.pincw <- read_csv(paste0(db.here, "IDDRC_D84_Best_PAX6inCW.csv"))
s.pincw <- read_csv(paste0(db.here, "IDDRC_D84_Smol_PAX6inCW.csv"))

# GLOBALS ##########################################################################################
Site.color <-c("#12783D", "#882155", "#4040C6")
Replicate.shapes <- c(0,1,2,3,4,15,16,17)

# TOPRO VOL #######################################################################
#remove duplicate topro measurement in best
b.t.v <- mutate(b.t.v, uniqueID = paste(filename,TotalVolume))
b.t.v <- filter(b.t.v, uniqueID != "IDDRc_BestS3_UNC_R5P1CDP2CD_se 3259146914.6417")
b.t.v <- dplyr::select(b.t.v, !c(uniqueID))
b.t.v <- mutate(b.t.v, TotalVolume = TotalVolume/1000000000)

# TOPRO VOL #######################################################################
ANOVAToPRO <- aov(TotalVolume~Site, data = b.t.v)
SiteANOVA <- summary(ANOVAToPRO)
#save p-val for FDR correction
BestTopROP <- 0.938

VolbyEBID <- (ggplot(b.t.v, aes(x=Site, y=TotalVolume, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(7.7,7.7,8.3))+
  ylab("ToPRO Volume mm cubed")+ ylim(0,9)+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 10)))
VolbyEBID
#ggsave("June25_BestVol_D84.pdf",plot = last_plot(), width = 125, height = 197,
#       units = "mm",dpi = 300, device = "png",
#       path = "/work/users/r/o/roseg/IDDRC/IDDRCPlots/iDISCO/")
#export as 2.76 by 5.15 inportrait

s.t.v <- mutate(s.t.v, TotalVolume = TotalVolume/1000000000)

# TOPRO VOL #######################################################################
ANOVAToPRO <- aov(TotalVolume~Site, data = s.t.v)
SiteANOVA <- summary(ANOVAToPRO)
SmallTopROP <-  0.582

VolbyEBID <- (ggplot(s.t.v, aes(x=Site, y=TotalVolume, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(4,4,4.5))+
  ylab("ToPRO Volume mm cubed")+ ylim(0,9)+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 10)))
VolbyEBID
#ggsave("June25_SmolVol_D84.pdf",plot = last_plot(), width = 125, height = 197,
#       units = "mm",dpi = 300, device = "png",
#       path = "/work/users/r/o/roseg/IDDRC/IDDRCPlots/iDISCO/")

#CTIP2 in VZ ####################################################################
#remove smols2_cn_1cb_hco1_pax6_s1_Are because of split PAX6 surfaces
s.cinvz <- filter(s.cinvz, filename != "smols2_cn_1cb_hco1_pax6_s1_Are")
s.cinvz <- filter(s.cinvz, filename != "smols2_cn_1cb_hco1_pax6_s2_Are")

# PAX6 in Cortical Wall #######################################################################
ANOVAcinvz <- aov(CWoverlap~Site, data = b.cinvz)
SiteANOVA <- summary(ANOVAcinvz)
BestCinVZP <-  0.361

VolbyEBID <- (ggplot(b.cinvz, aes(x=Site, y=CWoverlap, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(0.4,0.4,0.45))+  ylab("Percent CTIP2 in VZ-like Zone")+ ylim(0,0.5)+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID

# PAX6 in Cortical Wall #######################################################################
ANOVAcinvz <- aov(CWoverlap~Site, data = s.cinvz)
SiteANOVA <- summary(ANOVAcinvz)
SmallCinVZP <-  0.86

VolbyEBID <- (ggplot(s.cinvz, aes(x=Site, y=CWoverlap, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(0.32,0.32,0.37))+  ylab("Percent CTIP2 in VZ-like Zone")+ ylim(0,0.5)+
ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID

FDRtest <- rbind(BestCinVZP,BestTopROP,SmallTopROP,SmallCinVZP)
FDRtest <- as.data.frame(FDRtest)
FDRtest <- mutate(FDRtest, FDRCheck = p.adjust(V1, method = "BH"))
