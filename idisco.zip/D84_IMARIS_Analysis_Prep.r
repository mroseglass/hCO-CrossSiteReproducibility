library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

# volume across sites for each set
#actually Best sets still have pretty high overlap between CTIP2 & PAX6, but not some much for prog in ctip2
#density plots CTIP2 spots to PAX6
  #check if spots have shorter distances to nearest neighbor in CTIP2+ CW like zones

#INPUTS
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/"
B.ctipspot.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Spots/"
B.ctipwall.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Wall/"
B.pax6.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestPAX6/"
B.topro.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestToPRO/"

#Volume #####################################################################################
List.round <- c(list.files(B.topro.here))
i=1
List.analysis <- list.files(paste0(B.topro.here,List.round[i]))
vol <- grep("Volume.csv",List.analysis)
vol <- read_delim(paste0(B.topro.here,List.round[i],"/",List.analysis[vol]),skip = 3)
#Sum total volume
TotalVol <- vol %>%
  dplyr::summarise(TotalVolume = sum(Volume, na.rm = TRUE))
#for merging all the files together, add first 30 characters from name
filename <- substr(List.analysis[1],1,30)
TotalVol.all <- cbind(TotalVol,filename)

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.topro.here,List.round[i]))
  vol <- grep("Volume.csv",List.analysis)
  vol <- read_delim(paste0(B.topro.here,List.round[i],"/",List.analysis[vol]),skip = 3)
  #Sum total volume
  TotalVol <- vol %>%
    dplyr::summarise(TotalVolume = sum(Volume, na.rm = TRUE))
  #for merging all the files together, add first 30 characters from name
  filename <- substr(List.analysis[1],1,30)
  TotalVol <- cbind(TotalVol,filename)
  TotalVol.all <- rbind(TotalVol,TotalVol.all)
}  

#for separating Best_CN_first&second
CN_1n2.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/Best_CN_to_Sep/IDDRc_BestS3_cN_R6P1CDP2CD_firstandsecond_AS_hCO1TopRO_Statistics/"
CN_1n2 <-  c(list.files(CN_1n2.here))
#bind y position and Volume by id
ypos <- read_delim(paste0(CN_1n2.here,CN_1n2[67]),skip = 3)
ToPRO <- read_delim(paste0(CN_1n2.here,CN_1n2[79]),skip = 3)
CN_1n2_hCO <- inner_join(ypos,ToPRO, by = "ID")
CN_hCO1 <- filter(CN_1n2_hCO, `Position Y` < 5000)
#Sum total volume
CN_hCO1 <- CN_hCO1 %>%
  dplyr::summarise(TotalVolume = sum(Volume, na.rm = TRUE))
#for merging all the files together, add first 30 characters from name, from ID converter
filename <- "IDDRc_BestS3_cN_R6P1CDP2CD_fir"
CN_hCO1 <- cbind(CN_hCO1,filename)
CN_hCO2 <- filter(CN_1n2_hCO, `Position Y` > 5000)
CN_hCO2 <- CN_hCO2 %>%
  dplyr::summarise(TotalVolume = sum(Volume, na.rm = TRUE))
#for merging all the files together, add first 30 characters from name, from ID converter
filename <- "IDDRc_BestS3_cN_R6P1CDP2CD_fir"
CN_hCO2 <- cbind(CN_hCO2,filename)
imaris.id.convert <- read_csv(paste0(db.here,"iDISCO/D84Best_ToPRO_IMARIS_IDConvert.csv"))
CN_hCO1 <- inner_join(imaris.id.convert, CN_hCO1, by = "filename")
CN_hCO2 <- inner_join(imaris.id.convert, CN_hCO2, by = "filename")

#pull unique filename to IDconversion
#IMARIS.name <- as_tibble(unique(TotalVol.all$filename))
#write_csv(IMARIS.name, paste0(db.here,"D84Best_ToPRO_IMARIS_IDConvert.csv"))
TotalVol.all <- full_join(imaris.id.convert, TotalVol.all, by = "filename")
TotalVol.all <- rbind(TotalVol.all, CN_hCO1)
TotalVol.all$filename <- gsub("IDDRc_BestS3_cN_R6P1CDP2CD_fir","IDDRc_BestS3_cN_R6P1CDP2CD_fir_Ypos<5K",TotalVol.all$filename)
TotalVol.all <- rbind(TotalVol.all, CN_hCO2)
TotalVol.all$filename <- gsub("IDDRc_BestS3_cN_R6P1CDP2CD_fir","IDDRc_BestS3_cN_R6P1CDP2CD_fir_Ypos>5K",TotalVol.all$filename)
TotalVol.all <- TotalVol.all %>% drop_na(TotalVolume)

#write_csv(TotalVol.all,paste0(db.here, "IDDRC_D84_Best_ToPRO.csv"))

#CTIP2spots to VZ #####################################################################################
#for separating Best_CN_first&second
CN_1n2.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/Best_CN_to_Sep/17-08IDDRc_BestS3_cN_R6P1CDP2CD_firstandsecond_AS_CTIP2spots_Statistics/"
CN_1n2 <-  c(list.files(CN_1n2.here))
#bind y position and Volume by id
ypos <- read_delim(paste0(CN_1n2.here,CN_1n2[85]),skip = 3)
ToPRO <- read_delim(paste0(CN_1n2.here,CN_1n2[102]),skip = 3)
CN_1n2_hCO <- inner_join(ypos,ToPRO, by = "ID")
#spots are only from 1 hCO so the files has been moved back into the same folder

#try to filter spots by distance from topro
List.round <- c(list.files(B.ctipspot.here))
i=1
List.analysis <- list.files(paste0(B.ctipspot.here,List.round[i]))
ctip2s <- grep("Surfaces_Surfaces=P",List.analysis)
ctip2s.d <- read_delim(paste0(B.ctipspot.here,List.round[i],"/",List.analysis[ctip2s]),skip = 3)
ctip2s.d <- dplyr::rename(ctip2s.d, ShortestDistancetoVZ = `Shortest Distance to Surfaces`)
ctip2s <- grep("Surfaces_Surfaces=T",List.analysis)
ctip2s.t <- read_delim(paste0(B.ctipspot.here,List.round[i],"/",List.analysis[ctip2s]),skip = 3)
ctip2s.t <- dplyr::rename(ctip2s.t, ShortestDistancetoTopro = `Shortest Distance to Surfaces`)
spots <- inner_join(ctip2s.t,ctip2s.d, by = "ID")
#remove spots outside of hCO
spots <- filter(spots, ShortestDistancetoTopro < 0)
spots <- select(spots, c(ShortestDistancetoTopro,ShortestDistancetoVZ))

#for merging all the files together, add first 30 characters from name
filename <- substr(List.analysis[1],1,30)
ctip2s.d.all <- cbind(spots,filename)

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.ctipspot.here,List.round[i]))
  ctip2s <- grep("Surfaces_Surfaces=P",List.analysis)
  ctip2s.d <- read_delim(paste0(B.ctipspot.here,List.round[i],"/",List.analysis[ctip2s]),skip = 3)
  ctip2s.d <- dplyr::rename(ctip2s.d, ShortestDistancetoVZ = `Shortest Distance to Surfaces`)
  ctip2s <- grep("Surfaces_Surfaces=T",List.analysis)
  ctip2s.t <- read_delim(paste0(B.ctipspot.here,List.round[i],"/",List.analysis[ctip2s]),skip = 3)
  ctip2s.t <- dplyr::rename(ctip2s.t, ShortestDistancetoTopro = `Shortest Distance to Surfaces`)
  spots <- inner_join(ctip2s.t,ctip2s.d, by = "ID")
  #remove spots outside of hCO
  spots <- filter(spots, ShortestDistancetoTopro < 0)
  spots <- select(spots, c(ShortestDistancetoTopro,ShortestDistancetoVZ))
  
  #for merging all the files together, add first 30 characters from name
  filename <- substr(List.analysis[1],1,30)
  ctip2s.d <- cbind(spots,filename)
  ctip2s.d.all <- rbind(ctip2s.d.all,ctip2s.d)
  }

#pull unique filename to IDconversion
#IMARIS.name <- as_tibble(unique(ctip2s.d.all$filename))
#write_csv(IMARIS.name, paste0(db.here,"D84Best_CTIP2Spots_IMARIS_IDConvert.csv"))
imaris.id.convert <- read_csv(paste0(db.here,"D84Best_CTIP2Spots_IMARIS_IDConvert.csv"))
ctip2s.d.all <- full_join(imaris.id.convert, ctip2s.d.all, by = "filename")

write_csv(ctip2s.d.all,paste0(db.here, "IDDRC_D84_Best_CTIP2Spots.csv"))

p<-ggplot(ctip2s.d.all, aes(x=ShortestDistancetoVZ, color=filename)) +
  geom_density()
p

p<-ggplot(spots, aes(x=ShortestDistancetoTopro, y=ShortestDistancetoVZ)) +
  geom_point()
p

#CTIP2 to PAX6 overlap #####################################################################################
List.round <- c(list.files(B.ctipwall.here))
i=1
List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
cwinvz <- grep("Volume_to_Surfaces_Surfaces=P",List.analysis)
cwinvz.o <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwinvz]),skip = 3)
#Sum total overlapped volume
Sum.cwinvz <- cwinvz.o %>%
  dplyr::summarise(cwinvz = sum(`Overlapped Volume to Surfaces`, na.rm = TRUE))
#pull total pax6vol
cw <- grep("Volume.csv",List.analysis)
cw.v <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cw]),skip = 3)
#Sum total overlapped volume
Sum.cw <- cw.v %>%
  dplyr::summarise(cw = sum(Volume, na.rm = TRUE))

#get overlap
CTIP2inVZ <- cbind(Sum.cwinvz,Sum.cw)
CTIP2inVZ <- mutate(CTIP2inVZ, CWoverlap = cwinvz/cw)
#for merging all the files together, add first 30 characters from name
filename <- substr(List.analysis[1],1,30)
CTIP2inVZ.all <- cbind(CTIP2inVZ,filename)

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
  cwinvz <- grep("Volume_to_Surfaces_Surfaces=P",List.analysis)
  cwinvz.o <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwinvz]),skip = 3)
  #Sum total overlapped volume
  Sum.cwinvz <- cwinvz.o %>%
    dplyr::summarise(cwinvz = sum(`Overlapped Volume to Surfaces`, na.rm = TRUE))
  #pull total pax6vol
  cw <- grep("Volume.csv",List.analysis)
  cw.v <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cw]),skip = 3)
  #Sum total overlapped volume
  Sum.cw <- cw.v %>%
    dplyr::summarise(cw = sum(Volume, na.rm = TRUE))
  
  #get overlap
  CTIP2inVZ <- cbind(Sum.cwinvz,Sum.cw)
  CTIP2inVZ <- mutate(CTIP2inVZ, CWoverlap = cwinvz/cw)
  #for merging all the files together, add first 30 characters from name
  filename <- substr(List.analysis[1],1,30)
  CTIP2inVZ <- cbind(CTIP2inVZ,filename)
  CTIP2inVZ.all <- rbind(CTIP2inVZ.all, CTIP2inVZ)
  }

#pull unique filename to IDconversion
IMARIS.name <- as_tibble(unique(CTIP2inVZ.all$filename))
#write_csv(IMARIS.name, paste0(db.here,"D84Best_CTIP2inVZ_IMARIS_IDConvert.csv"))
imaris.id.convert <- read_csv(paste0(db.here,"iDISCO/D84Best_CTIP2inVZ_IMARIS_IDConvert_THISFILE.csv"))
CTIP2inVZ.all <- full_join(imaris.id.convert, CTIP2inVZ.all, by = "filename")

write_csv(CTIP2inVZ.all,paste0(db.here, "IDDRC_D84_Best_CTIP2inVZ.csv"))

#DO NOT USE PAX6 to CTIP overlap ###########################################################################################
#Example opening of one file
List.round <- c(list.files(B.pax6.here))
i=2
List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
#pull overlaped to CTIP-wall
vz.cw <- grep("Volume_to_Surfaces_Surfaces=C",List.analysis)
vz.cw.o <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[vz.cw]),skip = 3)
#Sum total overlapped volume
Sum.vz.cw <- vz.cw.o %>%
  dplyr::summarise(cp.vz = sum(`Overlapped Volume to Surfaces`, na.rm = TRUE))
#pull total pax6vol
vz <- grep("Volume.csv",List.analysis)
vz.v <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[vz]),skip = 3)
#Sum total overlapped volume
Sum.vz <- vz.v %>%
  dplyr::summarise(vz = sum(Volume, na.rm = TRUE))

#get overlap
pax6inCW <- cbind(Sum.vz.cw,Sum.vz)
pax6inCW <- mutate(pax6inCW, CWoverlap = cp.vz/vz)
#for merging all the files together, add first 30 characters from name
filename <- substr(List.analysis[1],1,30)
pax6inCW.all <- cbind(pax6inCW,filename)

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
  #pull overlaped to CTIP-wall
  vz.cw <- grep("Volume_to_Surfaces_Surfaces=C",List.analysis)
  vz.cw.o <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[vz.cw]),skip = 3)
  #Sum total overlapped volume
  Sum.vz.cw <- vz.cw.o %>%
    dplyr::summarise(cp.vz = sum(`Overlapped Volume to Surfaces`, na.rm = TRUE))
  #pull total pax6vol
  vz <- grep("Volume.csv",List.analysis)
  vz.v <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[vz]),skip = 3)
  #Sum total overlapped volume
  Sum.vz <- vz.v %>%
    dplyr::summarise(vz = sum(Volume, na.rm = TRUE))
  
  #get overlap
  pax6inCW <- cbind(Sum.vz.cw,Sum.vz)
  pax6inCW <- mutate(pax6inCW, CWoverlap = cp.vz/vz)
  #for merging all the files together, add first 30 characters from name
  filename <- substr(List.analysis[1],1,30)
  pax6inCW <- cbind(pax6inCW,filename)
    pax6inCW.all <- rbind(pax6inCW.all,pax6inCW)
}

#pull unique filename to IDconversion
#IMARIS.name <- as_tibble(unique(pax6inCW.all$filename))
#write_csv(IMARIS.name, paste0(db.here,"D84Best_PAX6inCW_IMARIS_IDConvert.csv"))
imaris.id.convert <- read_csv(paste0(db.here,"D84Best_PAX6inCW_IMARIS_IDConvert.csv"))
pax6inCW.all <- full_join(imaris.id.convert, pax6inCW.all, by = "filename")

write_csv(pax6inCW.all,paste0(db.here, "IDDRC_D84_Best_PAX6inCW.csv"))
