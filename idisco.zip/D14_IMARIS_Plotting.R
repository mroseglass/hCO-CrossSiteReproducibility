library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggplot2)
library(ggpubr)
library(plotrix)
library("ggsignif")
######################################################################################
setwd("/work/users/r/o/roseg")
HERE <- "/work/users/r/o/roseg/single-cell_reproducibility/"
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/iDISCO/"

# GLOBALS ##########################################################################################
Site.color <-c("#12783D", "#882155", "#4040C6")
Replicate.shapes <- c(0,1,2,3,4,15,16,17)

iddrc.d14 <- read_csv(paste0(db.here,"D14_IMARIS_Combined.csv"))
iddrc.d14$Rep <-gsub("lot1","Pilot",iddrc.d14$Rep) 

#remove CHOP Rep6 and CHOP Rep5
iddrc.d14 <- filter(iddrc.d14, image != "CHOP_Rep6_hCO1")
iddrc.d14 <- filter(iddrc.d14, image != "CHOP_Rep5_hCO1")

#Plot ToPRO Full Volume
#is not significant
#changes to mm3 instead of micron cubes
iddrc.d14$ToPROVolume <- iddrc.d14$ToPROVolume/1000000000
ANOVAToPRO <- aov(ToPROVolume~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVAToPRO)
PToproD14 <- 0.000789

VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=ToPROVolume, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                 c("CN", "UNC"),
                                 c("UNC","CHOP")),
                                 y_position = c(0.4,0.4,0.5))+
  ylab("ToPRO Volume mm cubed")+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 3)))
VolbyEBID

#Plot Percent PAX6
iddrc.d14$PAX6Volume <- iddrc.d14$PAX6Volume/1000000000
ANOVAPercentPax6 <- aov(percentpax6~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVAPercentPax6)
PPax6D14 <-0.29

VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=percentpax6, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +  
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                 c("CN", "UNC"),
                                 c("UNC","CHOP")),
              y_position = c(1.05,1,0.9)) +
  ylab("Percent PAX6")+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 3)))
  
VolbyEBID

#plot ToPRO and Pax6 proportion of NCAD area separately but on the same scale
ANOVA.NCADpPAX6 <- aov(NCADperPAX6~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVA.NCADpPAX6)
PNCADpPax6 <-0.0497

# NCAD to ToPRO and PAX6 Seperate y scale would be 0 to 0.02
VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=NCADperPAX6, fill = Site))) +
geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(0.02,0.02,0.022)) +
  ylab("NCAD+ Area micron2 per PAX6 Volume micron3")+ ylim(0, 0.024)+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 4)))
VolbyEBID

#is not significant
ANOVA.NCADperTotalVol <- aov(NCADperTotalVol~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVA.NCADperTotalVol)
PNCADpToPRO <- 0.131

# NCAD to ToPRO and PAX6 Seperate y scale would be 0 to 0.02
VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=NCADperTotalVol, fill = Site)))+
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                                 c("CN", "UNC"),
                                                 c("UNC","CHOP")),
              y_position = c(0.02,0.02,0.022)) +
  ylab("NCAD+ Area per ToPRO Volume")+ ylim(0, 0.024)+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 4)))
VolbyEBID

#FDR test
FDRtest <- rbind(PToproD14,PPax6D14,PNCADpPax6,PNCADpToPRO)
FDRtest <- as.data.frame(FDRtest)
FDRtest <- mutate(FDRtest, FDRCheck = p.adjust(V1, method = "BH"))



#plot PercentNCAD by Topro and pax6 ##############################################
#may not play nice with label t-tests
iddrc.d14 <- pivot_longer(iddrc.d14, cols = c(NCADperPAX6,NCADperTotalVol), names_to="Relativeto",values_to="PercentNCAD")

VolbyEBID <- (ggplot(iddrc.d14, aes(x=Relativeto, y=PercentNCAD, fill = Site))) +
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_set(theme_minimal())+
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(shape=Rep, size=2),position=position_jitterdodge(), alpha=0.7)+
  geom_signif(test = "t.test",comparisons = list(c("CN", "CHOP"),
                                 c("CN", "UNC"),
                                 c("UNC","CHOP")),
              y_position = c(0.013,0.014,0.015)) +
  ylab("NCAD+ Area per Total Volume")

VolbyEBID

#lm with experiment as random effect
iddrc.d14 <- mutate(iddrc.d14, Experiment = paste0(Site,Rep))
LMNCADperPAX6 <- lmer(NCADperPAX6 ~ as.factor(Site) + (1|Experiment), data = iddrc.d14)
summary(LMNCADperPAX6)

LMNCADperToPRO <- lmer(NCADperTotalVol ~ as.factor(Site) + (1|Experiment), data = iddrc.d14)
summary(LMNCADperToPRO)

#give warning so changing units, otherwise has similar results to ANOVA
iddrc.d14.m <- mutate(iddrc.d14, ToPROVolume = ToPROVolume/1e+08)
LMToPRO <- lmer(ToPROVolume ~ as.factor(Site) + (1|Experiment), data = iddrc.d14.m)
summary(LMToPRO)

LMpercentpax6 <- lmer(percentpax6 ~ as.factor(Site) + (1|Experiment), data = iddrc.d14.m)
summary(LMpercentpax6)


#############################
#Check iDISCO to Area
Area <- readRDS(paste0(rds.here, "IDDRCD14AreaReady.rds"))
#sumarize area by experiment, only works for older version of r!
D14AreabyExperiment <- Area %>%
  dplyr::group_by(Experiment) %>%
  dplyr::summarise(D14Area = mean(AreaMM2, na.rm = TRUE),
                   D14Area.sem = std.error(AreaMM2, na.rm = TRUE))
iddrc.d14 <- mutate(iddrc.d14, Experiment = paste0(Site,Rep))
iDISCObyExperiment <- iddrc.d14 %>%
  dplyr::group_by(Experiment) %>%
  dplyr::summarise(AvgVolume = mean(ToPROVolume, na.rm = TRUE),
                   ToPROVolume.sem = std.error(ToPROVolume, na.rm = TRUE))


iDISCOtoArea <- full_join(iDISCObyExperiment,D14AreabyExperiment, by = "Experiment")  
iDISCOtoArea <- mutate(iDISCOtoArea, Site =str_extract(iDISCOtoArea$Experiment, "[a-zA-Z]*R"))
iDISCObyArea <- filter(iDISCOtoArea, Site != "CNR")
iDISCObyArea <- iDISCObyArea%>% drop_na(ToPROVolume.sem)


test <- lm(AvgVolume~D14Area, data = iDISCObyArea)
result <- summary(test)
title <- "ToPRO Volume to Cross Sectional Area"

NCAD.p <- (ggplot(iDISCObyArea, aes(x=AvgVolume, y=D14Area))) +
  geom_smooth(method = lm, color = "black") +
  geom_point(size = 5, aes(col = Experiment)) +
  geom_errorbar(aes(ymin=D14Area-D14Area.sem, ymax=D14Area+D14Area.sem))+
  geom_errorbarh(aes(xmin=AvgVolume-ToPROVolume.sem, xmax=AvgVolume+ToPROVolume.sem),
                 position=position_dodge(.9)) +
  theme(axis.text.x = element_text(angle = 45)) +
  theme_bw()+ 
  #ggtitle(paste(title,"r =",round(test$estimate, digits = 3),"p = ", round(test$statistic,digits = 3))) +
  xlab("ToPRO Volume") +
  ylab("Cross Sectional Area")
NCAD.p


