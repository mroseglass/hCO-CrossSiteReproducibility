library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

# volume across sites for each set
#actually Best sets still have pretty high overlap between CTIP2 & PAX6, but not some much for prog in ctip2
#density plots CTIP2 spots to PAX6
#check if spots have shorter distances to nearest neighbor in CTIP2+ CW like zones

#INPUTS ##########################################################################################
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/"
rds.here <- "/work/users/r/o/roseg/IDDRC/IDDRC_EVOS/"
B.ctipspot.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Spots/"
B.ctipwall.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Wall/"
B.pax6.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestPAX6/"
B.topro.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestToPRO/"

#CTIP2 to PAX6 overlap #####################################################################################
List.round <- c(list.files(B.ctipwall.here))
i=1
List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
cwIntOut_ch4 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
#avg intensity outside surface
cwIntOut_ch4 <- cwIntOut_ch4 %>%
  dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
cwIntOut_ch2 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
#avg intensity outside surface
cwIntOut_ch2 <- cwIntOut_ch2 %>%
  dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
cwIntIn_ch4 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
#avg intensity outside surface
cwIntIn_ch4 <- cwIntIn_ch4 %>%
  dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
cwIntIn_ch2 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
#avg intensity outside surface
cwIntIn_ch2 <- cwIntIn_ch2 %>%
  dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

CW <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
CW.all <- CW
#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
  cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
  cwIntOut_ch4 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch4 <- cwIntOut_ch4 %>%
    dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
  cwIntOut_ch2 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch2 <- cwIntOut_ch2 %>%
    dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
  cwIntIn_ch4 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch4 <- cwIntIn_ch4 %>%
    dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
  cwIntIn_ch2 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch2 <- cwIntIn_ch2 %>%
    dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  CW <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
  CW.all <- rbind(CW.all, CW)
}

CW.p <-CW.all %>%  pivot_longer(!`List.round[i]`, names_to = "Intensity", values_to = "Image")
CW.p.in <- filter(CW.p, Intensity != "Ch4IntOut")
CW.p.in$Intensity <- factor(CW.p.in$Intensity, 
                          levels=c("Ch2IntIn","Ch4IntIn","Ch2IntOut"))


VolbyEBID <- (ggplot(CW.p.in, aes(x=Intensity, y=Image, fill = Intensity))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  theme_classic()+ 
  geom_point(aes(color = `List.round[i]`),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
geom_line(aes(group = `List.round[i]`),color="grey")
  #ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID

#pull unique filename to IDconversion
#IMARIS.name <- as_tibble(unique(CTIP2inVZ.all$filename))
#write_csv(IMARIS.name, paste0(db.here,"D84Best_CTIP2inVZ_IMARIS_IDConvert.csv"))
#imaris.id.convert <- read_csv(paste0(db.here,"D84Best_CTIP2inVZ_IMARIS_IDConvert.csv"))
#CTIP2inVZ.all <- full_join(imaris.id.convert, CTIP2inVZ.all, by = "filename")

#write_csv(CTIP2inVZ.all,paste0(db.here, "IDDRC_D84_Best_CTIP2inVZ.csv"))

#PAX6 to CTIP2 overlap #####################################################################################
List.round <- c(list.files(B.pax6.here))
i=1
List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
cwIntOut_ch4 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
#avg intensity outside surface
cwIntOut_ch4 <- cwIntOut_ch4 %>%
  dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
cwIntOut_ch2 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
#avg intensity outside surface
cwIntOut_ch2 <- cwIntOut_ch2 %>%
  dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
cwIntIn_ch4 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
#avg intensity outside surface
cwIntIn_ch4 <- cwIntIn_ch4 %>%
  dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
cwIntIn_ch2 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
#avg intensity outside surface
cwIntIn_ch2 <- cwIntIn_ch2 %>%
  dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

VZ <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
VZ.all <- VZ

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
  cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
  cwIntOut_ch4 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch4 <- cwIntOut_ch4 %>%
    dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
  cwIntOut_ch2 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch2 <- cwIntOut_ch2 %>%
    dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
  cwIntIn_ch4 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch4 <- cwIntIn_ch4 %>%
    dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
  cwIntIn_ch2 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch2 <- cwIntIn_ch2 %>%
    dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  VZ <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
  VZ.all <- rbind(VZ.all, VZ)
}


VZ.p <-VZ.all %>%  pivot_longer(!`List.round[i]`, names_to = "Intensity", values_to = "Image")
VZ.p.in <- filter(VZ.p, Intensity != "Ch4IntOut")
VZ.p.in$Intensity <- factor(VZ.p.in$Intensity, 
                            levels=c("Ch2IntIn","Ch4IntIn","Ch2IntOut"))


VolbyEBID <- (ggplot(VZ.p.in, aes(x=Intensity, y=Image, fill = Intensity))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  theme_classic()+ 
  geom_point(aes(color = `List.round[i]`),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_line(aes(group = `List.round[i]`),color="grey")
#ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID

# SCRATCH ########################################################################
# Check that CW annotation make sense by comparing to CTIP2+ Spots? ########################################
# would use grep for Density_Outside_Surfaces=C and Density_Inside_Surfaces=C
#could support previous analysis but they just look to poor and don't reproduce well 

#filters bad image CTIP2 surfaces #########################################################################
bad.ctip <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Wall/cN_Best2_cD_ctip2bands_Statistics"
List.analysis <- c(list.files(bad.ctip))
vol <- grep("Volume.csv",List.analysis)
vol <- read_delim(paste0(bad.ctip,"/",List.analysis[vol]),skip = 3)
pax6m <- grep("Intensity_Min_Ch=2",List.analysis)
pax6m <- read_delim(paste0(bad.ctip,"/",List.analysis[pax6m]),skip = 3)
paxm.f <- inner_join(vol,pax6m, by = "ID")

p<-ggplot(paxm.f, aes(x=`Intensity Min`)) +
  geom_density()
p
paxm.f <- filter(paxm.f, `Intensity Min` <1500)
IDstfilter_CN_CD <- paxm.f$ID

#other bad image #######################################################################################
bad.ctip <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Best/BestCTIP2Wall_Filtered/IDDRc_BestS3_cHOP_R6C10C6_first_Aligned_STITCHED_CTIP2wall_Statistics"
List.analysis <- c(list.files(bad.ctip))
vol <- grep("Volume.csv",List.analysis)
vol <- read_delim(paste0(bad.ctip,"/",List.analysis[vol]),skip = 3)
pax6m <- grep("Intensity_Min_Ch=2",List.analysis)
pax6m <- read_delim(paste0(bad.ctip,"/",List.analysis[pax6m]),skip = 3)
paxm.f <- inner_join(vol,pax6m, by = "ID")

p<-ggplot(paxm.f, aes(x=`Intensity Min`)) +
  geom_density()
p
paxm.f <- filter(paxm.f, `Intensity Min` <3500)
IDstfilter_CHOP_C6C10first <- paxm.f$ID

cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
cwIntOut_ch4 <- read_delim(paste0(bad.ctip,"/",List.analysis[cwIntOut_ch4]),skip = 3)
#avg intensity outside surface
cwIntOut_ch4 <- cwIntOut_ch4 %>%
  dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
cwIntOut_ch2 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
#avg intensity outside surface
cwIntOut_ch2 <- cwIntOut_ch2 %>%
  dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
cwIntIn_ch4 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
#avg intensity outside surface
cwIntIn_ch4 <- cwIntIn_ch4 %>%
  dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
cwIntIn_ch2 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
#avg intensity outside surface
cwIntIn_ch2 <- cwIntIn_ch2 %>%
  dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

CW <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
