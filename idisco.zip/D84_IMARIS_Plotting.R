library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

#INPUTS ########################################################################################
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/iDISCO/"
rds.here <- "/work/users/r/o/roseg/IDDRC/IDDRC_EVOS/"
b.t.v <- read_csv(paste0(db.here, "IDDRC_D84_Best_ToPRO.csv"))
s.t.v <- read_csv(paste0(db.here, "IDDRC_D84_Smol_TotalVolume.csv"))
b.ctip2.spot <- read_csv(paste0(db.here, "IDDRC_D84_Best_CTIP2Spots.csv"))
s.ctip2.spot <- read_csv(paste0(db.here, "IDDRC_D84_Smol_CTIP2Spots.csv"))
b.cinvz <- read_csv(paste0(db.here, "IDDRC_D84_Best_CTIP2inVZ.csv"))
s.cinvz <- read_csv(paste0(db.here, "IDDRC_D84_Smol_CTIP2inVZ.csv"))
b.pincw <- read_csv(paste0(db.here, "IDDRC_D84_Best_PAX6inCW.csv"))
s.pincw <- read_csv(paste0(db.here, "IDDRC_D84_Smol_PAX6inCW.csv"))

# GLOBALS ##########################################################################################
Site.color <-c("#12783D", "#882155", "#4040C6")
Replicate.shapes <- c(0,1,2,3,4,15,16,17)

# TOPRO VOL #######################################################################
#remove duplicate topro measurement in best
b.t.v <- mutate(b.t.v, uniqueID = paste(filename,TotalVolume))
b.t.v <- filter(b.t.v, uniqueID != "IDDRc_BestS3_UNC_R5P1CDP2CD_se 3259146914.6417")
b.t.v <- dplyr::select(b.t.v, !c(uniqueID))

#get Best and smol in same graph
Quality <- rep("small",length(s.t.v$TotalVolume)) 
s.t.v <- cbind(s.t.v,Quality)
Quality <- rep("best",length(b.t.v$TotalVolume)) 
b.t.v <- cbind(b.t.v,Quality)
AllTopro <- rbind(s.t.v,b.t.v)
AllTopro <- mutate(AllTopro, SiteQC = paste(Site,Quality))
AllTopro$SiteQC <- factor(AllTopro$SiteQC, 
                       levels=c('CHOP best','CHOP small',
                                'CN best','CN small',
                                'UNC best','UNC small'))

#convert units 
AllTopro <- mutate(AllTopro, TotalVolume = TotalVolume/1000000000)
#huge topro point is 2 hCOs probably, has class A vs no Class
#otherwise could try to separate through y positions

# TOPRO VOL #######################################################################
ANOVAToPRO <- aov(TotalVolume~Quality, data = AllTopro)
SiteANOVA <- summary(ANOVAToPRO)

VolbyEBID <- (ggplot(AllTopro, aes(x=SiteQC, y=TotalVolume, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  #geom_point(aes(shape = Replicate),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN best", "CHOP best"),
                                                 c("CN best", "UNC best"),
                                                 c("UNC best","CHOP best"),
                                                 c("CN best","CN small"),
                                                 c("UNC best","UNC small"),
                                                 c("CHOP best","CHOP small")),
              y_position = c(8.6,8.6,9.5,7.7,7.7,7.7))+
  ylab("ToPRO Volume mm cubed")+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 10)))
VolbyEBID

#check CN best and small
checkCNToPRO <-filter(AllTopro, Site == "CN")
CNbest <- filter(checkCNToPRO, Quality == "best")
CNsmall <- filter(checkCNToPRO, Quality == "small")
t.test(x = CNbest$TotalVolume , y = CNsmall$TotalVolume,
       alternative = c("two.sided"))

write_csv(AllTopro,"/work/users/r/o/roseg/IDDRC/IDDRCDatabase/iDISCO/AllD84ToPro.csv")
#CTP2 spots #############################################################################
# visualize relationship between distance from topro to vz
# spots for images 2in1 CN images are jsut from one hCO
pb<-ggplot(b.ctip2.spot, aes(x=ShortestDistancetoTopro, y=ShortestDistancetoVZ)) +
  geom_point() + ggtitle("Best CTIP2 Spots")
pb

ps<-ggplot(s.ctip2.spot, aes(x=ShortestDistancetoTopro, y=ShortestDistancetoVZ)) +
  geom_point() + ggtitle("Small CTIP2 Spots")
ps

#remove smols2_cn_1cb_hco1_pax6_s1_Are because of split PAX6 surfaces
s.ctip2.spot <- filter(s.ctip2.spot, filename != "smols2_cn_1cb_hco1_pax6_s1_Are")
s.ctip2.spot <- filter(s.ctip2.spot, filename != "smols2_cn_1cb_hco1_pax6_s2_Are")

# filter by 200, 175, 150,125 100 um into ToPRO
Quality <- rep("small",length(s.ctip2.spot$ShortestDistancetoTopro)) 
s.ctip2.spot <- cbind(s.ctip2.spot,Quality)

Quality <- rep("best",length(b.ctip2.spot$ShortestDistancetoTopro)) 
b.ctip2.spot <- cbind(b.ctip2.spot,Quality)
AllSpot <- rbind(s.ctip2.spot,b.ctip2.spot)
AllSpot <- mutate(AllSpot, SiteQC = paste(Site,Quality))
AllSpot$SiteQC <- factor(AllSpot$SiteQC, 
                          levels=c('CHOP best','CHOP small',
                                   'CN best','CN small',
                                   'UNC best','UNC small'))
AllSpot.f <- filter(AllSpot, ShortestDistancetoTopro > -150)
AllSpot.f.cw <- filter(AllSpot.f, ShortestDistancetoVZ > 0)
AllSpot.f.vz <- filter(AllSpot.f, ShortestDistancetoVZ < 0)

p<-ggplot(AllSpot.f.cw, aes(x=ShortestDistancetoVZ, color=SiteQC)) +
  geom_density() + ggtitle("Spots 150um or less into TopRO")
p

smallspot <- filter(AllSpot.f, Quality == "small")
bestspot <- filter(AllSpot.f, Quality == "best")

p<-ggplot(smallspot, aes(x=ShortestDistancetoVZ, color=filename)) +
  geom_density() + ggtitle("Small Spots 150um or less into TopRO")
p + facet_wrap(vars(Site))

p<-ggplot(bestspot, aes(x=ShortestDistancetoVZ, color=filename)) +
  geom_density() + ggtitle("Best Spots 150um or less into TopRO") 
p + facet_wrap(vars(Site))

linesbysite <- 
  c("#4040C6","#882155","#4040C6","#12783D","#12783D",
    "#882155","#882155","#882155","#4040C6","#4040C6",
    "#4040C6","#12783D","#12783D","#12783D","#12783D",
    "#882155","#882155","#4040C6","#4040C6","#4040C6",
    "#12783D","#12783D","#882155","#882155","#882155",
    "#4040C6","#4040C6","#4040C6")
p<-ggplot(AllSpot.f.cw, aes(x=ShortestDistancetoVZ, color=filename)) +
  geom_density() + ggtitle("Best Spots 150um or less into TopRO") +
  theme_classic() +
  scale_color_manual(values = linesbysite)
p + theme(legend.position = "none") + facet_wrap(vars(Site,Quality),scales = "free",nrow = 3)

#differences in means is probably ok for testing
avg.all.spot <- AllSpot.f.cw %>%
  group_by(filename) %>%
  dplyr::summarise(avgdis = mean(ShortestDistancetoVZ, na.rm = TRUE))
Converter <- distinct(select(AllSpot.f, c(Site,filename,Rep,Quality,SiteQC)))
avg.all.spot <- inner_join(Converter,avg.all.spot, by = "filename")
#avg.all.spot <- mutate(avg.all.spot, Site = gsub(" .*","",avg.all.spot$SiteQC))
#avg.all.spot <- mutate(avg.all.spot, Quality = gsub(".* ","",avg.all.spot$SiteQC))


spots.p <- (ggplot(avg.all.spot , aes(x=SiteQC, y=avgdis, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) +
  theme(axis.text.x = element_text(angle = 45)) +
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  scale_fill_manual(values = Site.color) +
  geom_signif(test = "t.test",comparisons = list(c("CN best", "CHOP best"),
                                                 c("CN best", "UNC best"),
                                                 c("UNC best","CHOP best"),
                                                 c("CN best","CN small"),
                                                 c("UNC best","UNC small"),
                                                 c("CHOP best","CHOP small")),
              y_position = c(250,250,300,170,170,170))+
  theme_classic()
print(spots.p)

# if you don't trust that the spots is a random undercountng of dense regions, then just look at maximum distance
AllSpot.f.cw.range <- AllSpot.f.cw %>%
  group_by(filename) %>%
  dplyr::summarise(maxdis = range(ShortestDistancetoVZ, na.rm = TRUE))
Converter <- distinct(select(AllSpot.f, c(Site,filename,Rep,Quality,SiteQC)))
AllSpot.f.cw.range <- inner_join(Converter,AllSpot.f.cw.range, by = "filename")
#just max distance
AllSpot.f.cw.range <-filter(AllSpot.f.cw.range, maxdis > 100)

#plot longest distances
spots.p <- (ggplot(AllSpot.f.cw.range , aes(x=SiteQC, y=maxdis, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) +
  theme(axis.text.x = element_text(angle = 45)) +
  geom_point(size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  scale_fill_manual(values = Site.color) +
  geom_signif(test = "t.test",comparisons = list(c("CN best", "CHOP best"),
                                                 c("CN best", "UNC best"),
                                                 c("UNC best","CHOP best"),
                                                 c("CN best","CN small"),
                                                 c("UNC best","UNC small"),
                                                 c("CHOP best","CHOP small")),
              y_position = c(1250,1250,1300,1170,1170,1170))+
  theme_classic()
print(spots.p)


#PAX6 in CW ###################################################################################
#remove smols2_cn_1cb_hco1_pax6_s1_Are because of split PAX6 surfaces
s.pincw <- filter(s.pincw, filename != "smols2_cn_1cb_hco1_pax6_s1_Are")
s.pincw <- filter(s.pincw, filename != "smols2_cn_1cb_hco1_pax6_s2_Are")

#get Best and smol in same graph
Quality <- rep("small",length(s.pincw$CWoverlap)) 
s.pincw <- cbind(s.pincw,Quality)
Quality <- rep("best",length(b.pincw$CWoverlap)) 
b.pincw <- cbind(b.pincw,Quality)
Allpincw <- rbind(s.pincw,b.pincw)
Allpincw <- mutate(Allpincw, SiteQC = paste(Site,Quality))
Allpincw$SiteQC <- factor(Allpincw$SiteQC, 
                       levels=c('CHOP best','CHOP small',
                                'CN best','CN small','UNC best','UNC small'))

# TOPRO VOL #######################################################################
ANOVApinccw <- aov(CWoverlap~Quality, data = Allpincw)
SiteANOVA <- summary(ANOVApinccw)

VolbyEBID <- (ggplot(Allpincw, aes(x=SiteQC, y=CWoverlap, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  #geom_point(aes(shape = Replicate),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN best", "CHOP best"),
                                                 c("CN best", "UNC best"),
                                                 c("UNC best","CHOP best"),
                                                 c("CN best","CN small"),
                                                 c("UNC best","UNC small"),
                                                 c("CHOP best","CHOP small")),
              y_position = c(1.5,1.5,1.8,1,1,1))+
  ylab("PAX6+ in Cortical Wall")+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 10)))
VolbyEBID

#good to double check manual annotation by looking at channel intentisty for NCAD & PAX6

write_csv(Allpincw,"/work/users/r/o/roseg/IDDRC/IDDRCDatabase/iDISCO/AllD84PAX6inCW.csv")
#CTIP2 in VZ ####################################################################
#remove smols2_cn_1cb_hco1_pax6_s1_Are because of split PAX6 surfaces
s.cinvz <- filter(s.cinvz, filename != "smols2_cn_1cb_hco1_pax6_s1_Are")
s.cinvz <- filter(s.cinvz, filename != "smols2_cn_1cb_hco1_pax6_s2_Are")

#get Best and smol in same graph
Quality <- rep("small",length(s.cinvz$CWoverlap)) 
s.cinvz <- cbind(s.cinvz,Quality)
Quality <- rep("best",length(b.cinvz$CWoverlap)) 
b.cinvz <- cbind(b.cinvz,Quality)
Allcinvz <- rbind(s.cinvz,b.cinvz)
Allcinvz <- mutate(Allcinvz, SiteQC = paste(Site,Quality))
Allcinvz$SiteQC <- factor(Allcinvz$SiteQC, 
                          levels=c('CHOP best','CHOP small',
                                   'CN best','CN small',
                                   'UNC best','UNC small'))

# PAX6 in Cortical Wall #######################################################################
ANOVAcinvz <- aov(CWoverlap~Quality, data = Allcinvz)
SiteANOVA <- summary(ANOVAcinvz)

VolbyEBID <- (ggplot(Allcinvz, aes(x=SiteQC, y=CWoverlap, fill = Site))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  scale_fill_manual(values = Site.color) +
  scale_shape_manual(values=Replicate.shapes)+
  theme_classic()+ 
  geom_point(aes(shape = Rep),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_signif(test = "t.test",comparisons = list(c("CN best", "CHOP best"),
                                                 c("CN best", "UNC best"),
                                                 c("UNC best","CHOP best"),
                                                 c("CN best","CN small"),
                                                 c("UNC best","UNC small"),
                                                 c("CHOP best","CHOP small")),
              y_position = c(0.9,0.9,1,0.7,0.7,0.7))+  ylab("Percent CTIP2 in VZ-like Zone")+
  ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID

#good to double check manual annotation by looking at channel intentisty for NCAD & PAX6

#SCRATCH ################################################################################################
ind.avg.all.spot <- AllSpot.f %>%
  group_by(filename) %>%
  dplyr::summarise(avgdis = mean(ShortestDistancetoVZ, na.rm = TRUE))
IDconverter <- select(AllSpot.f, c("Site","Quality","filename"))
ind.avg.all.spot <- inner_join(IDconverter,ind.avg.all.spot)
ind.avg.all.spot <- distinct(ind.avg.all.spot)

best.spots <- filter(ind.avg.all.spot, Quality =="best")
ANOVAspots <- aov(avgdis~Site, data = best.spots)
SiteANOVA <- summary(ANOVAspots)

smol.spots <- filter(ind.avg.all.spot, Quality =="small")
ANOVAspots <- aov(avgdis~Site, data = smol.spots)
SiteANOVA <- summary(ANOVAspots)

#cumulative distribution plots between the best and the smols per site
ggplot(AllSpot.f, aes(ShortestDistancetoVZ, colour = SiteQC)) +
  stat_ecdf()

#test 2 sites at a time or bestvsmol
#is of course significant because is super well powered
CHOP.smol <- filter(AllSpot.f, SiteQC == "CHOP small")
CHOP.best <- filter(AllSpot.f, SiteQC == "CHOP best")
ks.test(CHOP.best$ShortestDistancetoVZ, CHOP.smol$ShortestDistancetoVZ)

CN.best <- filter(AllSpot.f, SiteQC == "CN best")
UNC.best <- filter(AllSpot.f, SiteQC == "UNC best")
ks.test(CN.best$ShortestDistancetoVZ, UNC.best$ShortestDistancetoVZ)

