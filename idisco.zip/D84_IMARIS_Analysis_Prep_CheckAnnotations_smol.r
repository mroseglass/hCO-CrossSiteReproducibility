library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

#INPUTS
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/"
rds.here <- "/work/users/r/o/roseg/IDDRC/IDDRC_EVOS/"
B.ctipspot.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Smol/CTIP2spots/"
B.ctipwall.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Smol/CTIP2wall/"
B.pax6.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Smol/PAX6vol/"
B.topro.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISD84Analysis/Smol/ToPROVol/"

####
List.round <- c(list.files(B.ctipwall.here))
i=1
List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
cwIntOut_ch4 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
#avg intensity outside surface
cwIntOut_ch4 <- cwIntOut_ch4 %>%
  dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
cwIntOut_ch2 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
#avg intensity outside surface
cwIntOut_ch2 <- cwIntOut_ch2 %>%
  dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
cwIntIn_ch4 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
#avg intensity outside surface
cwIntIn_ch4 <- cwIntIn_ch4 %>%
  dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
cwIntIn_ch2 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
#avg intensity outside surface
cwIntIn_ch2 <- cwIntIn_ch2 %>%
  dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

CW <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
CW.all <- CW
#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.ctipwall.here,List.round[i]))
  cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
  cwIntOut_ch4 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch4 <- cwIntOut_ch4 %>%
    dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
  cwIntOut_ch2 <- read_delim(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch2 <- cwIntOut_ch2 %>%
    dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
  cwIntIn_ch4 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch4 <- cwIntIn_ch4 %>%
    dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
  cwIntIn_ch2 <- read_csv(paste0(B.ctipwall.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch2 <- cwIntIn_ch2 %>%
    dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  CW <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
  CW.all <- rbind(CW.all, CW)
}

CW.p <-CW.all %>%  pivot_longer(!`List.round[i]`, names_to = "Intensity", values_to = "Image")
CW.p.in <- filter(CW.p, Intensity != "Ch4IntOut")
CW.p.in$Intensity <- factor(CW.p.in$Intensity, 
                            levels=c("Ch2IntIn","Ch4IntIn","Ch2IntOut"))

## remove smols2_chop_c8c2_hco1_ctip2wall_Statistics

VolbyEBID <- (ggplot(CW.p.in, aes(x=Intensity, y=Image, fill = Intensity))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  theme_classic()+ 
  geom_point(aes(color = `List.round[i]`),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_line(aes(group = `List.round[i]`),color="grey")
#ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID


#PAX6 to CTIP2 overlap #####################################################################################
List.round <- c(list.files(B.pax6.here))
i=1
List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
cwIntOut_ch4 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
#avg intensity outside surface
cwIntOut_ch4 <- cwIntOut_ch4 %>%
  dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
cwIntOut_ch2 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
#avg intensity outside surface
cwIntOut_ch2 <- cwIntOut_ch2 %>%
  dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))

cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
cwIntIn_ch4 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
#avg intensity outside surface
cwIntIn_ch4 <- cwIntIn_ch4 %>%
  dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
cwIntIn_ch2 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
#avg intensity outside surface
cwIntIn_ch2 <- cwIntIn_ch2 %>%
  dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))

VZ <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
VZ.all <- VZ

#Add rest of files to same object
for (i in 2:length(List.round)){
  List.analysis <- list.files(paste0(B.pax6.here,List.round[i]))
  cwIntOut_ch4 <- grep("Intensity_Outside_Ch=4",List.analysis)
  cwIntOut_ch4 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch4 <- cwIntOut_ch4 %>%
    dplyr::summarise(Ch4IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntOut_ch2 <- grep("Intensity_Outside_Ch=2",List.analysis)
  cwIntOut_ch2 <- read_delim(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntOut_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntOut_ch2 <- cwIntOut_ch2 %>%
    dplyr::summarise(Ch2IntOut = mean(`Intensity Mean Outside`, na.rm = TRUE))
  
  cwIntIn_ch4 <- grep("Intensity_Inside_Ch=4",List.analysis)
  cwIntIn_ch4 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch4]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch4 <- cwIntIn_ch4 %>%
    dplyr::summarise(Ch4IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  cwIntIn_ch2 <- grep("Intensity_Inside_Ch=2",List.analysis)
  cwIntIn_ch2 <- read_csv(paste0(B.pax6.here,List.round[i],"/",List.analysis[cwIntIn_ch2]),skip = 3)
  #avg intensity outside surface
  cwIntIn_ch2 <- cwIntIn_ch2 %>%
    dplyr::summarise(Ch2IntIn = mean(`Intensity Mean Inside`, na.rm = TRUE))
  
  VZ <- cbind(List.round[i],cwIntIn_ch2,cwIntIn_ch4,cwIntOut_ch2,cwIntOut_ch4)
  VZ.all <- rbind(VZ.all, VZ)
}


VZ.p <-VZ.all %>%  pivot_longer(!`List.round[i]`, names_to = "Intensity", values_to = "Image")
VZ.p.in <- filter(VZ.p, Intensity != "Ch4IntOut")
VZ.p.in$Intensity <- factor(VZ.p.in$Intensity, 
                            levels=c("Ch2IntIn","Ch4IntIn","Ch2IntOut"))


VolbyEBID <- (ggplot(VZ.p.in, aes(x=Intensity, y=Image, fill = Intensity))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2, show.legend = FALSE) + 
  theme(axis.text.x = element_text(angle = 45)) +
  theme_classic()+ 
  geom_point(aes(color = `List.round[i]`),size = 2, position=position_jitterdodge(dodge.width=0.01),alpha=0.7) +
  geom_line(aes(group = `List.round[i]`),color="grey")
#ggtitle(paste("ANOVA pval=",round(SiteANOVA[[1]]$`Pr(>F)`, digits = 6)))
VolbyEBID
