library(tidyverse)
library(readxl)
library(lme4)
library(lmerTest)
library(ggpubr)
library(plotrix)

#volume for PAX6 and ToPRO
#Area for NCAD
#load in all analysis .csv files into single object

#INPUTS
db.here <- "/work/users/r/o/roseg/IDDRC/IDDRCDatabase/"
rds.here <- "/work/users/r/o/roseg/IDDRC/IDDRC_EVOS/"
pax6.csv.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISAnalysisD14/Statistics PAX6 IDDRC D14/"
ncad.csv.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISAnalysisD14/Statistics NCAD IDDRC D14/"
topro.csv.here <- "/work/users/r/o/roseg/IDDRC/IDDRCiDISCO/IMARISAnalysisD14/Statistics TopRO IDDRC D14/"

# PAX6 ###########################################################################################
#Example opening of one file
List.round <- c(list.files(pax6.csv.here))
i=1
List.analysis <- list.files(paste0(pax6.csv.here,List.round[i]))
Vol <- grep("Volume.csv",List.analysis)
Vol.p <- read_delim(paste0(pax6.csv.here,List.round[i],"/",List.analysis[Vol]),skip = 3)

#for merging all the files together, add filename
filename <- gsub ("titch.*","",List.analysis[1])
Add.ImageID <- rep(c(filename),each=length(Vol.p$Volume))
CorrectFile <- cbind(Vol.p,Add.ImageID)
D14.P <- CorrectFile

#Add rest of files to same object
#not all Volume in Same Place
for (i in 1:length(List.round)){
  List.analysis <- list.files(paste0(pax6.csv.here,List.round[i]))
  Vol <- grep("Volume.csv",List.analysis)
  Vol.p <- read_delim(paste0(pax6.csv.here,List.round[i],"/",List.analysis[Vol]),skip = 3)
  filename <- gsub ("titch.*","",List.analysis[1])
  Add.ImageID <- rep(c(filename),each=length(Vol.p$Volume))
  CorrectFile <- cbind(Vol.p,Add.ImageID)
  D14.P <- rbind(D14.P,CorrectFile)
  }
#curently dropping "linty" sample, maybe ok

#pull unique Add.EBID to IDconversion
#IMARIS.name <- as_tibble(unique(D14.P$Add.ImageID))
#write_csv(IMARIS.name, paste0(db.here,"PAX6_IMARIS_IDConvert.csv"))

imaris.id.convert <- read_csv(paste0(db.here,"PAX6_IMARIS_IDConvert.csv"))
#make everything labeled as hCOnumber
D14.P <- full_join(imaris.id.convert, D14.P, by = "Add.ImageID")
#Drop surfaces labeled NaN
D14.P <- filter(D14.P, `Set 1` != "nan")


# remove Measurements not in hCO
D14.P.r <- D14.P%>% drop_na(`Set 1`)
D14.P.r <- dplyr::rename(D14.P.r, hCO = `Set 1`)
D14.P.r$hCO <- gsub(" ","", D14.P.r$hCO)
D14.P.r <- mutate(D14.P.r, image = paste(Experiment, hCO, sep = "_"))

#Sum EBID-HCO to get toal vol of each hCO
Sum.D14.P.r <- D14.P.r %>%
  dplyr::group_by(image) %>%
  dplyr::summarise(PAX6Volume = sum(Volume, na.rm = TRUE))

# Add site and  information back into R object
Sum.D14.P.r <- mutate(Sum.D14.P.r, Site = str_extract(Sum.D14.P.r$image, "[a-zA-Z]*_"))
Sum.D14.P.r <- mutate(Sum.D14.P.r, Site = gsub("_","",Site))
Sum.D14.P.r <- mutate(Sum.D14.P.r, Rep = str_sub(Sum.D14.P.r$image, -9,-6))
Sum.D14.P.r <- mutate(Sum.D14.P.r, hCO = str_sub(Sum.D14.P.r$image,-4,-1))
#write_csv(Sum.IVIV.14.T.r,paste0(db.here, "IVIVD14ToPRO.csv"))

#Check Distribution #######################################################################
histo <- (ggplot(Sum.D14.P.r, aes(x=PAX6Volume))) +
  geom_histogram()
histo

VolbyEBID <- (ggplot(Sum.D14.P.r, aes(x=Site, y=PAX6Volume))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=Rep),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

# NCAD #####################################################################################
#Example opening of one file
List.round <- c(list.files(ncad.csv.here))
i=1
List.analysis <- list.files(paste0(ncad.csv.here,List.round[i]))
Area <- grep("Area.csv",List.analysis)
Area.p <- read_delim(paste0(ncad.csv.here,List.round[i],"/",List.analysis[Area]),skip = 3)

#for merging all the files together, add filename
filename <- gsub ("titch.*","",List.analysis[1])
Add.ImageID <- rep(c(filename),each=length(Area.p$Area))
CorrectFile <- cbind(Area.p,Add.ImageID)
D14.N <- CorrectFile

#Add rest of files to same object
for (i in 1:length(List.round)){
  List.analysis <- list.files(paste0(ncad.csv.here,List.round[i]))
  Area <- grep("Area.csv",List.analysis)
  Area.p <- read_delim(paste0(ncad.csv.here,List.round[i],"/",List.analysis[Area]),skip = 3)
  filename <- gsub ("titch.*","",List.analysis[1])
  Add.ImageID <- rep(c(filename),each=length(Area.p$Area))
  CorrectFile <- cbind(Area.p,Add.ImageID)
  D14.N <- rbind(D14.N,CorrectFile)
}

#pull unique Add.EBID to IDconversion
#IMARIS.name <- as_tibble(unique(D14.N$Add.ImageID))
#write_csv(IMARIS.name, paste0(db.here,"NCAD_IMARIS_IDConvert.csv"))

imaris.id.convert <- read_csv(paste0(db.here,"NCAD_IMARIS_IDConvert.csv"))
#make everything labeled as hCOnumber
D14.N <- inner_join(imaris.id.convert, D14.N, by = "Add.ImageID")

#Drop surfaces labeled NaN
D14.N <- filter(D14.N, `Set 1` != "NA")
D14.N <- filter(D14.N, `Set 1` != "Nana")
D14.N <- filter(D14.N, `Set 1` != "Nan")

# remove Measurements not in hCO
D14.N.r <- D14.N%>% drop_na(`Set 1`)
D14.N.r <- dplyr::rename(D14.N.r, hCO = `Set 1`)
D14.N.r <- mutate(D14.N.r, image = paste(Experiment, hCO, sep = "_"))
#make unique ID fo each NCAD surface
D14.N.r <- mutate(D14.N.r, NCADobject = paste(as.character(Area), image, sep = "_"))

#Check Distribution #
histo <- (ggplot(D14.N.r, aes(x=Area))) +
  geom_histogram()
histo

#Buds greater than 50 uM
D14.N.r <- filter(D14.N.r, Area > 50)
Top2.5 <- quantile(D14.N.r$Area, 0.975)
Bottom2.5 <- quantile(D14.N.r$Area, 0.025)
D14.N.r <- filter(D14.N.r, Area < Top2.5)
D14.N.r <- filter(D14.N.r, Area > Bottom2.5)

#Sum EBID-HCO to get toal vol of each hCO
Sum.D14.N.r <- D14.N.r %>%
  dplyr::group_by(image) %>%
  dplyr::summarise(AreaNCAD = sum(Area, na.rm = TRUE),
                   CountNCAD = n_distinct(NCADobject, na.rm = TRUE))

# Add site and  information back into R object
Sum.D14.N.r <- mutate(Sum.D14.N.r, Site = str_extract(Sum.D14.N.r$image, "[a-zA-Z]*_"))
Sum.D14.N.r <- mutate(Sum.D14.N.r, Site = gsub("_","",Site))
Sum.D14.N.r <- mutate(Sum.D14.N.r, Rep = str_sub(Sum.D14.N.r$image, -9,-6))
Sum.D14.N.r <- mutate(Sum.D14.N.r, hCO = str_sub(Sum.D14.N.r$image,-4,-1))
#write_csv(Sum.IVIV.14.T.r,paste0(db.here, "IVIVD14ToPRO.csv"))

#Check Distribution #######################################################################
histo <- (ggplot(Sum.D14.N.r, aes(x=AreaNCAD))) +
  geom_histogram()
histo

VolbyEBID <- (ggplot(Sum.D14.N.r, aes(x=Site, y=AreaNCAD))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=Rep),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

# ToPRO #####################################################################################
#Example opening of one file
List.round <- c(list.files(topro.csv.here))
i=1
List.analysis <- list.files(paste0(topro.csv.here,List.round[i]))
Vol <- grep("Volume.csv",List.analysis)
Vol.t <- read_delim(paste0(topro.csv.here,List.round[i],"/",List.analysis[Vol]),skip = 3)

#for merging all the files together, add filename
filename <- gsub ("titch.*","",List.analysis[1])
Add.ImageID <- rep(c(filename),each=length(Vol.t$Volume))
CorrectFile <- cbind(Vol.t,Add.ImageID)
D14.T <- CorrectFile

#Add rest of files to same object
#not all Volume in Same Place
for (i in 2:31){
  List.analysis <- list.files(paste0(topro.csv.here,List.round[i]))
  Vol <- grep("Volume.csv",List.analysis)
  Vol.t <- read_delim(paste0(topro.csv.here,List.round[i],"/",List.analysis[Vol]),skip = 3)
  filename <- gsub ("titch.*","",List.analysis[1])
  Add.ImageID <- rep(c(filename),each=length(Vol.t$Volume))
  CorrectFile <- cbind(Vol.t,Add.ImageID)
  D14.T <- rbind(D14.T,CorrectFile)
}

#pull unique Add.Image to IDconversion
#IMARIS.name <- as_tibble(unique(D14.T$Add.ImageID))
#write_csv(IMARIS.name, paste0(db.here,"ToPRO_IMARIS_IDConvert.csv"))

imaris.id.convert <- read_csv(paste0(db.here,"ToPRO_IMARIS_IDConvert (2).csv"))
#make everything labeled as hCOnumber
D14.T <- inner_join(imaris.id.convert, D14.T, by = "Add.ImageID")

#Drop surfaces labeled NaN
D14.T <- filter(D14.T, `Set 1` != "NA")
D14.T <- filter(D14.T, `Set 1` != "NaN")
D14.T <- filter(D14.T, `Set 1` != "Nan")

# remove Measurements not in hCO
D14.T.r <- D14.T%>% drop_na(`Set 1`)
D14.T.r <- dplyr::rename(D14.T.r, hCO = `Set 1`)
D14.T.r <- mutate(D14.T.r, image = paste(Experiment, hCO, sep = "_"))

#Sum EBID-HCO to get toal vol of each hCO
Sum.D14.T.r <- D14.T.r %>%
  dplyr::group_by(image) %>%
  dplyr::summarise(ToPROVolume = sum(Volume, na.rm = TRUE))

# Add site and  information back into R object
Sum.D14.T.r <- mutate(Sum.D14.T.r, Site = str_extract(Sum.D14.T.r$image, "[a-zA-Z]*_"))
Sum.D14.T.r <- mutate(Sum.D14.T.r, Site = gsub("_","",Site))
Sum.D14.T.r <- mutate(Sum.D14.T.r, Rep = str_sub(Sum.D14.T.r$image, -9,-6))
Sum.D14.T.r <- mutate(Sum.D14.T.r, hCO = str_sub(Sum.D14.T.r$image,-4,-1))

#Check Distribution #######################################################################
histo <- (ggplot(Sum.D14.T.r, aes(x=ToPROVolume))) +
  geom_histogram()
histo

VolbyEBID <- (ggplot(Sum.D14.T.r, aes(x=Site, y=ToPROVolume))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=Rep),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

####################################################################
#combine all dataframe by image id
iddrc.d14 <- full_join(Sum.D14.P.r,Sum.D14.N.r, by = "image")
iddrc.d14 <- full_join(iddrc.d14,Sum.D14.T.r, by = "image")
iddrc.d14 <- dplyr::select(iddrc.d14, c(image,Site.y,Rep.y,hCO.y,PAX6Volume,ToPROVolume,AreaNCAD,CountNCAD))
iddrc.d14 <- dplyr::rename(iddrc.d14, Site=Site.y)
iddrc.d14 <- dplyr::rename(iddrc.d14, Rep=Rep.y)
iddrc.d14 <- dplyr::rename(iddrc.d14, hCO=hCO.y)
#UNC Rep4 looks labeled incorrectly for ToPRO&PAX6, flip them
iddrc.d14.UR4 <- filter(iddrc.d14, Rep == "Rep4")
iddrc.d14.UR4 <- filter(iddrc.d14.UR4, Site == "UNC")
iddrc.d14 <- anti_join(iddrc.d14,iddrc.d14.UR4)
iddrc.d14.UR4 <- dplyr::rename(iddrc.d14.UR4, PAXVolumeN = ToPROVolume)
iddrc.d14.UR4 <- dplyr::rename(iddrc.d14.UR4, ToPROVolume=PAX6Volume)
iddrc.d14.UR4 <- dplyr::rename(iddrc.d14.UR4, PAX6Volume=PAXVolumeN)
iddrc.d14 <- rbind(iddrc.d14,iddrc.d14.UR4)


iddrc.d14 <- mutate(iddrc.d14, percentpax6 = PAX6Volume/ToPROVolume)
iddrc.d14 <- mutate(iddrc.d14, NCADperTotalVol = AreaNCAD/ToPROVolume)
iddrc.d14 <- mutate(iddrc.d14, NCADperPAX6 = AreaNCAD/PAX6Volume)

#remove incomplete hCO
iddrc.d14 <- filter(iddrc.d14, image != "UNC_Rep1_hCO1")
iddrc.d14 <- filter(iddrc.d14, image != "CN_Rep4_hCO2")
write_csv(iddrc.d14, paste0(db.here,"D14_IMARIS_Combined.csv"))



#check that topro greater than pax6 greater than NCAD | NOT YET
VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=percentpax6))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=Rep),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=NCADperTotalVol))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=hCO),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

VolbyEBID <- (ggplot(iddrc.d14, aes(x=Site, y=NCADperPAX6))) +
  geom_boxplot(outlier.shape = NA, lwd=0.2) + 
  geom_point(aes(color=hCO),position=position_jitterdodge(), alpha=0.9)+
  theme(axis.text.x = element_text(angle = 45)) 
VolbyEBID

#is not significant
ANOVAPercentPax6 <- aov(percentpax6~Site, data = iddrc.d14)
  SiteANOVA <- summary(ANOVAPercentPax6)
  
#is significant
ANOVA.NCADpPAX6 <- aov(NCADperPAX6~Site, data = iddrc.d14)
                  SiteANOVA <- summary(ANOVA.NCADpPAX6)
                  
#is not significant
ANOVA.NCADperTotalVol <- aov(NCADperTotalVol~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVA.NCADperTotalVol)

#is significant
ANOVA.ToPROVolume <- aov(ToPROVolume~Site, data = iddrc.d14)
SiteANOVA <- summary(ANOVA.ToPROVolume)
                  
                                    

#correlate NCAD to ToPRO | filter 2.5% and minimum Area is 50 | add counts of NCAD
#More surfaces, more area SOMEBUDS BROKEN INTO MULTIPLE OBJECT DO NOT USE
test <- cor.test(iddrc.d14$AreaNCAD,iddrc.d14$CountNCAD, method = "pearson")
title <- "NCAD count to NCAD Area"

NCAD.p <- (ggplot(iddrc.d14, aes(x=CountNCAD, y=AreaNCAD))) +
  geom_smooth(method = lm, color = "black") +
  geom_point(size = 5, aes(col = Site)) +
  theme(axis.text.x = element_text(angle = 45)) +
  theme_bw()+
  ggtitle(paste(title,"r =",round(test$estimate, digits = 3),"p = ", round(test$statistic,digits = 3))) +
  xlab("Count NCAD Surface") +
  ylab("Total NCAD Area")
NCAD.p

#More NCAD, more ToPRO
test <- cor.test(iddrc.d14$AreaNCAD,iddrc.d14$ToPROVolume, method = "pearson")
title <- "ToPRO Volume to NCAD Area"

NCAD.p <- (ggplot(iddrc.d14, aes(x=ToPROVolume, y=AreaNCAD))) +
  geom_smooth(method = lm, color = "black") +
  geom_point(size = 5, aes(col = Site)) +
  theme(axis.text.x = element_text(angle = 45)) +
  theme_bw()+
  ggtitle(paste(title,"r =",round(test$estimate, digits = 3),"p = ", round(test$statistic,digits = 3))) +
  xlab("ToPRO Volume") +
  ylab("Total NCAD Area")
NCAD.p

#Keep unique NCADsurface for each hCO
NCAD.Topro <- full_join(D14.N.r,Sum.D14.T.r, by = "image")
#average NCAD area per hCO
NCADbyhCO <- (ggplot(NCAD.Topro, aes(x=image, y=Area))) +
  geom_violin(aes(color=Site))+
  geom_boxplot(outlier.shape = NA, lwd=0.1) + 
  #geom_point(aes(color=Site),position=position_jitterdodge(), alpha=0.9)+
  scale_y_continuous(trans='log10') +
  theme(axis.text.x = element_text(angle = 45)) 
NCADbyhCO

#Check iDISCO to Area
Area <- readRDS(paste0(rds.here, "IDDRCD14AreaReady.rds"))
#sumarize area by experiment, only works for older version of r!
D14AreabyExperiment <- Area %>%
  dplyr::group_by(Experiment) %>%
  dplyr::summarise(D14Area = mean(AreaMM2, na.rm = TRUE),
                   D14Area.sem = std.error(AreaMM2, na.rm = TRUE))
iddrc.d14 <- mutate(iddrc.d14, Experiment = paste0(Site,Rep))
iDISCObyExperiment <- iddrc.d14 %>%
  dplyr::group_by(Experiment) %>%
  dplyr::summarise(AvgVolume = mean(ToPROVolume, na.rm = TRUE),
                   ToPROVolume.sem = std.error(ToPROVolume, na.rm = TRUE))


iDISCOtoArea <- full_join(iDISCObyExperiment,D14AreabyExperiment, by = "Experiment")  
iDISCOtoArea <- mutate(iDISCOtoArea, Site =str_extract(iDISCOtoArea$Experiment, "[a-zA-Z]*R"))
iDISCObyArea <- filter(iDISCOtoArea, Site != "CNR")
iDISCObyArea <- iDISCObyArea%>% drop_na(ToPROVolume.sem)


test <- lm(AvgVolume~D14Area, data = iDISCObyArea)
result <- summary(test)
title <- "ToPRO Volume to Cross Sectional Area"

NCAD.p <- (ggplot(iDISCObyArea, aes(x=AvgVolume, y=D14Area))) +
  geom_smooth(method = lm, color = "black") +
  geom_point(size = 5, aes(col = Experiment)) +
  geom_errorbar(aes(ymin=D14Area-D14Area.sem, ymax=D14Area+D14Area.sem))+
  geom_errorbarh(aes(xmin=AvgVolume-ToPROVolume.sem, xmax=AvgVolume+ToPROVolume.sem),
                 position=position_dodge(.9)) +
  theme(axis.text.x = element_text(angle = 45)) +
  theme_bw()+ 
  #ggtitle(paste(title,"r =",round(test$estimate, digits = 3),"p = ", round(test$statistic,digits = 3))) +
  xlab("ToPRO Volume") +
  ylab("Cross Sectional Area")
NCAD.p


#then check for Site to Site differences
  #color by Rep 

